from aiogram import Bot, Dispatcher, types
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils import executor

from flask import Flask
import threading
import os

API_TOKEN = "توکن_ربات_اینجا"

ADMIN_ID = "@idarkfail"
CHANNEL_ID = "@xvpnconfigs"

bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot)

app = Flask(__name__)

@app.route('/')
def home():
    return "Bot is running"

def run_web():
    port = int(os.environ.get("PORT", 10000))
    app.run(host="0.0.0.0", port=port)

threading.Thread(target=run_web).start()

main_kb = types.ReplyKeyboardMarkup(resize_keyboard=True)
main_kb.add("💰 خرید اشتراک")
main_kb.add("📦 سرویس های من", "🆘 پشتیبانی")

plans = {
    "1": 270000,
    "2": 530000,
    "3": 790000,
    "4": 1000000,
    "5": 1200000,
    "10": 2180000
}

async def is_member(user_id):
    try:
        member = await bot.get_chat_member(CHANNEL_ID, user_id)
        return member.status in ["member", "administrator", "creator"]
    except:
        return False

@dp.message_handler(commands=['start'])
async def start(message: types.Message):

    if not await is_member(message.from_user.id):
        await message.answer(
            "❌ برای استفاده از ربات باید عضو کانال شوید:\n@xvpnconfigs"
        )
        return

    await message.answer(
        "👋 به ربات خوش آمدید",
        reply_markup=main_kb
    )

@dp.message_handler(text="💰 خرید اشتراک")
async def buy(message: types.Message):

    text = """📦 جزئیات محصولات:

📦 حجم: 1GB
💰 قیمت: 270,000 تومان

📦 حجم: 2GB
💰 قیمت: 530,000 تومان

📦 حجم: 3GB
💰 قیمت: 790,000 تومان

📦 حجم: 4GB
💰 قیمت: 1,000,000 تومان

📦 حجم: 5GB
💰 قیمت: 1,200,000 تومان

📦 حجم: 10GB
💰 قیمت: 2,180,000 تومان

⏳ مدت زمان: 30 روز
👥 کاربر نامحدود
🔗 همراه با لینک ساب

🛍️ لطفاً سرویس مورد نظر را انتخاب کنید!
"""

    kb = InlineKeyboardMarkup(row_width=2)

    kb.add(
        InlineKeyboardButton("1GB", callback_data="plan_1"),
        InlineKeyboardButton("2GB", callback_data="plan_2"),
        InlineKeyboardButton("3GB", callback_data="plan_3"),
        InlineKeyboardButton("4GB", callback_data="plan_4"),
        InlineKeyboardButton("5GB", callback_data="plan_5"),
        InlineKeyboardButton("10GB", callback_data="plan_10"),
    )

    await message.answer(text, reply_markup=kb)

@dp.callback_query_handler(lambda c: c.data.startswith("plan_"))
async def plan(call: types.CallbackQuery):

    p = call.data.split("_")[1]
    price = plans[p]

    text = f"""📇 پیش فاکتور شما:

🔐 سرویس: {p}GB
👤 نام کاربری: xvpnbot_2610
⏳ مدت / 📦 حجم: 30 روز / {p} گیگ

💶 مبلغ: {price} تومان

💳 موجودی کیف پول: 0 تومان
📥 کسری قابل پرداخت: {price} تومان

💰 سفارش شما آماده پرداخت است.
"""

    kb = InlineKeyboardMarkup()

    kb.add(
        InlineKeyboardButton(
            "💰 پرداخت و دریافت سرویس",
            callback_data=f"pay_{p}"
        ),
        InlineKeyboardButton(
            "🏡 بازگشت به منوی اصلی",
            callback_data="home"
        )
    )

    await call.message.answer(text, reply_markup=kb)

@dp.callback_query_handler(lambda c: c.data.startswith("pay_"))
async def pay(call: types.CallbackQuery):

    p = call.data.split("_")[1]
    price = plans[p]

    text = f"""💳 برای دریافت شماره کارت، فقط به پشتیبانی پیام دهید.

👤 آیدی پشتیبانی:
{ADMIN_ID}

💰 مبلغ قابل پرداخت:
{price} تومان

پس از واریز روی دکمه ارسال رسید بزنید.
"""

    kb = InlineKeyboardMarkup()

    kb.add(
        InlineKeyboardButton(
            "🪪 دریافت شماره کارت از پشتیبانی",
            url=f"https://t.me/{ADMIN_ID.replace('@','')}"
        ),
        InlineKeyboardButton(
            "📸 پرداخت کردم ارسال رسید",
            callback_data="receipt"
        )
    )

    await call.message.answer(text, reply_markup=kb)

@dp.callback_query_handler(lambda c: c.data == "receipt")
async def receipt(call: types.CallbackQuery):
    await call.message.answer("📸 لطفاً تصویر رسید را ارسال کنید")

@dp.message_handler(content_types=['photo'])
async def get_receipt(message: types.Message):

    await bot.forward_message(
        chat_id=ADMIN_ID,
        from_chat_id=message.chat.id,
        message_id=message.message_id
    )

    await message.answer("✅ رسید شما ارسال شد")

@dp.message_handler(text="📦 سرویس های من")
async def my_services(message: types.Message):
    await message.answer("📦 هنوز سرویسی ندارید")

@dp.message_handler(text="🆘 پشتیبانی")
async def support(message: types.Message):
    await message.answer(f"👤 پشتیبانی:\n{ADMIN_ID}")

if __name__ == "__main__":
    executor.start_polling(dp)
